RAGWarrant arXiv LaTeX source package
====================================

Source manuscript: RAGWarrant_Governance.docx
Converted manuscript version: v0.1.1-rc1 (September 2026)
Authors: Richard Krueger, Lucas Krause, Zach Pocquette

Contents
--------
main.tex       Main arXiv source file
figure1.png    Governance loop
figure2.png    Canonical promotion logic
figure3.png    Evidence ladder and claim ceiling
figure4.png    Cloud-agnostic deployment contract
figure5.png    Empirical evidence map
figure6.png    Selector stress test

Build
-----
pdflatex main.tex
pdflatex main.tex

The source uses only standard TeX Live packages and an inline thebibliography,
so no BibTeX/Biber pass is required.

Conversion note
---------------
The manuscript text, tables, claims, numerical values, references, and the six
embedded figure images were preserved from the supplied DOCX. The embedded
artwork itself was not rewritten. In particular, source artwork that contains
legacy "RAGTune" wording remains exactly as supplied in the Word document.
